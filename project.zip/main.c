#include <stdio.h>
#include <stdlib.h> 
#include "pico/stdlib.h"
#include "hardware/adc.h"
#include "hardware/i2c.h"
#include "hardware/uart.h"

// ================= Configurações dos Pinos =================
#define UART_ID uart0
#define BAUD_RATE 115200
#define UART_TX_PIN 0
#define UART_RX_PIN 1

// Motores de Passo
#define DIR_ESQ 14
#define STEP_ESQ 15
#define DIR_DIR 16
#define STEP_DIR 17

// Controles (Joystick, Botão e Potenciômetro)
#define JOYSTICK_Y_PIN 26 // ADC0
#define JOYSTICK_X_PIN 27 // ADC1
#define POTENCIOMETRO_PIN 28 // ADC2
#define BTN_FREIO 5

// Display OLED e LED
#define I2C_PORT i2c0
#define I2C_SDA 12
#define I2C_SCL 13
#define LED_STATUS 22

// ================= Variáveis Globais =================
int velocidade_esq = 0;
int velocidade_dir = 0;
volatile bool freio_ativado = false; 
uint32_t ultimo_envio_telemetria = 0;

// ================= Interrupção =================
void botao_callback(uint gpio, uint32_t events) {
    if (gpio == BTN_FREIO) {
        freio_ativado = !freio_ativado; 
    }
}

// ================= Funções Auxiliares =================
int limitar_velocidade(int valor) {
    if (valor > 100) return 100;
    if (valor < -100) return -100;
    return valor;
}

void setup_geral() {
    stdio_init_all();

    uart_init(UART_ID, BAUD_RATE);
    gpio_set_function(UART_TX_PIN, GPIO_FUNC_UART);
    gpio_set_function(UART_RX_PIN, GPIO_FUNC_UART);

    gpio_init(DIR_ESQ); gpio_set_dir(DIR_ESQ, GPIO_OUT);
    gpio_init(STEP_ESQ); gpio_set_dir(STEP_ESQ, GPIO_OUT);
    gpio_init(DIR_DIR); gpio_set_dir(DIR_DIR, GPIO_OUT);
    gpio_init(STEP_DIR); gpio_set_dir(STEP_DIR, GPIO_OUT);

    // Inicializa o ADC para os 3 eixos analógicos
    adc_init();
    adc_gpio_init(JOYSTICK_Y_PIN);
    adc_gpio_init(JOYSTICK_X_PIN);
    adc_gpio_init(POTENCIOMETRO_PIN); // Inicializa o pino do Potenciômetro

    gpio_init(BTN_FREIO);
    gpio_set_dir(BTN_FREIO, GPIO_IN);
    gpio_pull_up(BTN_FREIO);
    gpio_set_irq_enabled_with_callback(BTN_FREIO, GPIO_IRQ_EDGE_FALL, true, &botao_callback);

    i2c_init(I2C_PORT, 400 * 1000);
    gpio_set_function(I2C_SDA, GPIO_FUNC_I2C);
    gpio_set_function(I2C_SCL, GPIO_FUNC_I2C);
    gpio_pull_up(I2C_SDA);
    gpio_pull_up(I2C_SCL);

    gpio_init(LED_STATUS);
    gpio_set_dir(LED_STATUS, GPIO_OUT);
    gpio_put(LED_STATUS, 0); 
}

// ================= Loop Principal =================
int main() {
    setup_geral();
    uart_puts(UART_ID, "Sistema Robótico com Controle de Potência Iniciado!\r\n");

    while (true) {
        // --- 1. LEITURA DOS SENSORES ANALÓGICOS ---
        adc_select_input(0); 
        int eixo_y = ((adc_read() - 2048) * 100) / 2048;
        
        adc_select_input(1); 
        int eixo_x = ((adc_read() - 2048) * 100) / 2048;

        // Leitura do Potenciômetro (ADC2) - Converte de 0-4095 para 0-100%
        adc_select_input(2);
        int limite_potencia = (adc_read() * 100) / 4095;

        if (eixo_y > -10 && eixo_y < 10) eixo_y = 0;
        if (eixo_x > -10 && eixo_x < 10) eixo_x = 0;

        // --- 2. MIXAGEM E LIMITAÇÃO DE POTÊNCIA ---
        if (freio_ativado) {
            velocidade_esq = 0;
            velocidade_dir = 0;
        } else {
            // Calcula a velocidade base do Joystick
            int vel_base_esq = limitar_velocidade(eixo_y + eixo_x);
            int vel_base_dir = limitar_velocidade(eixo_y - eixo_x);
            
            // Aplica o "Fator de Corte" do Potenciômetro
            velocidade_esq = (vel_base_esq * limite_potencia) / 100;
            velocidade_dir = (vel_base_dir * limite_potencia) / 100;
        }

        // --- 3. TELEMETRIA IOT VIA UART ---
        uint32_t tempo_atual = to_ms_since_boot(get_absolute_time());
        if (tempo_atual - ultimo_envio_telemetria > 500) {
            
            char buffer_json[200]; 
            // Agora enviamos também o "limite_potencia" no JSON
            snprintf(buffer_json, sizeof(buffer_json), 
                     "{\"freio\": %s, \"vel_E\": %d, \"vel_D\": %d, \"Y\": %d, \"X\": %d, \"max_pot\": %d}\r\n", 
                     freio_ativado ? "true" : "false", velocidade_esq, velocidade_dir, eixo_y, eixo_x, limite_potencia);
            
            uart_puts(UART_ID, buffer_json);
            gpio_put(LED_STATUS, !gpio_get(LED_STATUS)); 
            ultimo_envio_telemetria = tempo_atual;
        }

        // --- 4. ATUAÇÃO (Motores de Passo) ---
        if (velocidade_esq != 0 || velocidade_dir != 0) {
            gpio_put(DIR_ESQ, velocidade_esq >= 0 ? 0 : 1); 
            gpio_put(DIR_DIR, velocidade_dir >= 0 ? 0 : 1);

            if (velocidade_esq != 0) gpio_put(STEP_ESQ, 1);
            if (velocidade_dir != 0) gpio_put(STEP_DIR, 1);
            
            sleep_us(500); 
            
            gpio_put(STEP_ESQ, 0);
            gpio_put(STEP_DIR, 0);
            
            int vel_media = (abs(velocidade_esq) + abs(velocidade_dir)) / 2;
            if (vel_media == 0) vel_media = 1; 
            sleep_ms(100 / vel_media); 
        } else {
            sleep_ms(10);
        }
    }

    return 0;
}